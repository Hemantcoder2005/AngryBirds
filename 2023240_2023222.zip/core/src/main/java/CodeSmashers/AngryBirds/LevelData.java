package CodeSmashers.AngryBirds;

public class LevelData {
    public int level;
    public String name;
    public String difficulty;
    // Add any other fields your JSON might contain
}
